# Bluesky 🍿 Cinema
View one Bluesky post at a time. Hide all the noise. Explore your feed with your keyboard.

# Usage  
- Next: j or ArrowRight
- Like: l
- Comments: i or c or ArrowUp
- Previous: k or ArrowLeft
- Reset: Escape
